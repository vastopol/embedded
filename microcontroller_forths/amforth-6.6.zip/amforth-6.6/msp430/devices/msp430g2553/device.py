MCUREGS = { 
    'P1IN': '$20',
    'P1OUT':'$21',
    'P1DIR':'$22',
    'P1REN':'$27',

    'P2IN' :'$28',
    'P2OUT':'$29',
    'P2DIR':'$2a',
    'P2REN':'$2f',

    'P3IN': '$18',
    'P3OUT':'$19',
    'P3DIR':'$1a',
    'P3REN':'$10',
    } 
