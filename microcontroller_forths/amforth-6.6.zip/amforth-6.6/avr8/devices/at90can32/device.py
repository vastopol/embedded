# Generated Automatically

# Partname AT90CAN32

MCUREGS = {
# Interrupt Vectors
	'INT0Addr' : '#2', # External Interrupt Request 0
	'INT1Addr' : '#4', # External Interrupt Request 1
	'INT2Addr' : '#6', # External Interrupt Request 2
	'INT3Addr' : '#8', # External Interrupt Request 3
	'INT4Addr' : '#10', # External Interrupt Request 4
	'INT5Addr' : '#12', # External Interrupt Request 5
	'INT6Addr' : '#14', # External Interrupt Request 6
	'INT7Addr' : '#16', # External Interrupt Request 7
	'TIMER2_COMPAddr' : '#18', # Timer/Counter2 Compare Match
	'TIMER2_OVFAddr' : '#20', # Timer/Counter2 Overflow
	'TIMER1_CAPTAddr' : '#22', # Timer/Counter1 Capture Event
	'TIMER1_COMPAAddr' : '#24', # Timer/Counter1 Compare Match A
	'TIMER1_COMPBAddr' : '#26', # Timer/Counter Compare Match B
	'TIMER1_COMPCAddr' : '#28', # Timer/Counter1 Compare Match C
	'TIMER1_OVFAddr' : '#30', # Timer/Counter1 Overflow
	'TIMER0_COMPAddr' : '#32', # Timer/Counter0 Compare Match
	'TIMER0_OVFAddr' : '#34', # Timer/Counter0 Overflow
	'CANITAddr' : '#36', # CAN Transfer Complete or Error
	'OVRITAddr' : '#38', # CAN Timer Overrun
	'SPI_STCAddr' : '#40', # SPI Serial Transfer Complete
	'USART0_RXAddr' : '#42', # USART0, Rx Complete
	'USART0_UDREAddr' : '#44', # USART0 Data Register Empty
	'USART0_TXAddr' : '#46', # USART0, Tx Complete
	'ANALOG_COMPAddr' : '#48', # Analog Comparator
	'ADCAddr' : '#50', # ADC Conversion Complete
	'EE_READYAddr' : '#52', # EEPROM Ready
	'TIMER3_CAPTAddr' : '#54', # Timer/Counter3 Capture Event
	'TIMER3_COMPAAddr' : '#56', # Timer/Counter3 Compare Match A
	'TIMER3_COMPBAddr' : '#58', # Timer/Counter3 Compare Match B
	'TIMER3_COMPCAddr' : '#60', # Timer/Counter3 Compare Match C
	'TIMER3_OVFAddr' : '#62', # Timer/Counter3 Overflow
	'USART1_RXAddr' : '#64', # USART1, Rx Complete
	'USART1_UDREAddr' : '#66', # USART1, Data Register Empty
	'USART1_TXAddr' : '#68', # USART1, Tx Complete
	'TWIAddr' : '#70', # 2-wire Serial Interface
	'SPM_READYAddr' : '#72', # Store Program Memory Read

# Module PORTA
	'PORTA' : '$22', # Port A Data Register
	'DDRA' : '$21', # Port A Data Direction Register
	'PINA' : '$20', # Port A Input Pins

# Module PORTB
	'PORTB' : '$25', # Port B Data Register
	'DDRB' : '$24', # Port B Data Direction Register
	'PINB' : '$23', # Port B Input Pins

# Module PORTC
	'PORTC' : '$28', # Port C Data Register
	'DDRC' : '$27', # Port C Data Direction Register
	'PINC' : '$26', # Port C Input Pins

# Module PORTD
	'PORTD' : '$2b', # Port D Data Register
	'DDRD' : '$2a', # Port D Data Direction Register
	'PIND' : '$29', # Port D Input Pins

# Module PORTE
	'PORTE' : '$2e', # Data Register, Port E
	'DDRE' : '$2d', # Data Direction Register, Port 
	'PINE' : '$2c', # Input Pins, Port E

# Module PORTF
	'PORTF' : '$31', # Data Register, Port F
	'DDRF' : '$30', # Data Direction Register, Port 
	'PINF' : '$2f', # Input Pins, Port F

# Module PORTG
	'PORTG' : '$34', # Data Register, Port G
	'DDRG' : '$33', # Data Direction Register, Port 
	'PING' : '$32', # Input Pins, Port G

# Module JTAG
	'OCDR' : '$51', # On-Chip Debug Related Register
	'MCUCR' : '$55', # MCU Control Register
	  'MCUCR_JTD': '$80', # JTAG Interface Disable
	'MCUSR' : '$54', # MCU Status Register
	  'MCUSR_JTRF': '$10', # JTAG Reset Flag

# Module SPI
	'SPCR' : '$4c', # SPI Control Register
	  'SPCR_SPIE': '$80', # SPI Interrupt Enable
	  'SPCR_SPE': '$40', # SPI Enable
	  'SPCR_DORD': '$20', # Data Order
	  'SPCR_MSTR': '$10', # Master/Slave Select
	  'SPCR_CPOL': '$8', # Clock polarity
	  'SPCR_CPHA': '$4', # Clock Phase
	  'SPCR_SPR': '$3', # SPI Clock Rate Selects
	'SPSR' : '$4d', # SPI Status Register
	  'SPSR_SPIF': '$80', # SPI Interrupt Flag
	  'SPSR_WCOL': '$40', # Write Collision Flag
	  'SPSR_SPI2X': '$1', # Double SPI Speed Bit
	'SPDR' : '$4e', # SPI Data Register

# Module TWI
	'TWBR' : '$b8', # TWI Bit Rate register
	'TWCR' : '$bc', # TWI Control Register
	  'TWCR_TWINT': '$80', # TWI Interrupt Flag
	  'TWCR_TWEA': '$40', # TWI Enable Acknowledge Bit
	  'TWCR_TWSTA': '$20', # TWI Start Condition Bit
	  'TWCR_TWSTO': '$10', # TWI Stop Condition Bit
	  'TWCR_TWWC': '$8', # TWI Write Collition Flag
	  'TWCR_TWEN': '$4', # TWI Enable Bit
	  'TWCR_TWIE': '$1', # TWI Interrupt Enable
	'TWSR' : '$b9', # TWI Status Register
	  'TWSR_TWS': '$f8', # TWI Status
	  'TWSR_TWPS': '$3', # TWI Prescaler
	'TWDR' : '$bb', # TWI Data register
	'TWAR' : '$ba', # TWI (Slave) Address register
	  'TWAR_TWA': '$fe', # TWI (Slave) Address register B
	  'TWAR_TWGCE': '$1', # TWI General Call Recognition E

# Module USART0
	'UDR0' : '$c6', # USART I/O Data Register
	'UCSR0A' : '$c0', # USART Control and Status Regis
	  'UCSR0A_RXC0': '$80', # USART Receive Complete
	  'UCSR0A_TXC0': '$40', # USART Transmitt Complete
	  'UCSR0A_UDRE0': '$20', # USART Data Register Empty
	  'UCSR0A_FE0': '$10', # Framing Error
	  'UCSR0A_DOR0': '$8', # Data overRun
	  'UCSR0A_UPE0': '$4', # Parity Error
	  'UCSR0A_U2X0': '$2', # Double the USART transmission 
	  'UCSR0A_MPCM0': '$1', # Multi-processor Communication 
	'UCSR0B' : '$c1', # USART Control and Status Regis
	  'UCSR0B_RXCIE0': '$80', # RX Complete Interrupt Enable
	  'UCSR0B_TXCIE0': '$40', # TX Complete Interrupt Enable
	  'UCSR0B_UDRIE0': '$20', # USART Data register Empty Inte
	  'UCSR0B_RXEN0': '$10', # Receiver Enable
	  'UCSR0B_TXEN0': '$8', # Transmitter Enable
	  'UCSR0B_UCSZ02': '$4', # Character Size
	  'UCSR0B_RXB80': '$2', # Receive Data Bit 8
	  'UCSR0B_TXB80': '$1', # Transmit Data Bit 8
	'UCSR0C' : '$c2', # USART Control and Status Regis
	  'UCSR0C_UMSEL0': '$40', # USART Mode Select
	  'UCSR0C_UPM0': '$30', # Parity Mode Bits
	  'UCSR0C_USBS0': '$8', # Stop Bit Select
	  'UCSR0C_UCSZ0': '$6', # Character Size
	  'UCSR0C_UCPOL0': '$1', # Clock Polarity
	'UBRR0' : '$c4', # USART Baud Rate Register t Byt

# Module USART1
	'UDR1' : '$ce', # USART I/O Data Register
	'UCSR1A' : '$c8', # USART Control and Status Regis
	  'UCSR1A_RXC1': '$80', # USART Receive Complete
	  'UCSR1A_TXC1': '$40', # USART Transmitt Complete
	  'UCSR1A_UDRE1': '$20', # USART Data Register Empty
	  'UCSR1A_FE1': '$10', # Framing Error
	  'UCSR1A_DOR1': '$8', # Data overRun
	  'UCSR1A_UPE1': '$4', # Parity Error
	  'UCSR1A_U2X1': '$2', # Double the USART transmission 
	  'UCSR1A_MPCM1': '$1', # Multi-processor Communication 
	'UCSR1B' : '$c9', # USART Control and Status Regis
	  'UCSR1B_RXCIE1': '$80', # RX Complete Interrupt Enable
	  'UCSR1B_TXCIE1': '$40', # TX Complete Interrupt Enable
	  'UCSR1B_UDRIE1': '$20', # USART Data register Empty Inte
	  'UCSR1B_RXEN1': '$10', # Receiver Enable
	  'UCSR1B_TXEN1': '$8', # Transmitter Enable
	  'UCSR1B_UCSZ12': '$4', # Character Size
	  'UCSR1B_RXB81': '$2', # Receive Data Bit 8
	  'UCSR1B_TXB81': '$1', # Transmit Data Bit 8
	'UCSR1C' : '$ca', # USART Control and Status Regis
	  'UCSR1C_UMSEL1': '$40', # USART Mode Select
	  'UCSR1C_UPM1': '$30', # Parity Mode Bits
	  'UCSR1C_USBS1': '$8', # Stop Bit Select
	  'UCSR1C_UCSZ1': '$6', # Character Size
	  'UCSR1C_UCPOL1': '$1', # Clock Polarity
	'UBRR1' : '$cc', # USART Baud Rate Register t Byt

# Module CPU
	'SREG' : '$5f', # Status Register
	  'SREG_I': '$80', # Global Interrupt Enable
	  'SREG_T': '$40', # Bit Copy Storage
	  'SREG_H': '$20', # Half Carry Flag
	  'SREG_S': '$10', # Sign Bit
	  'SREG_V': '$8', # Two's Complement Overflow Flag
	  'SREG_N': '$4', # Negative Flag
	  'SREG_Z': '$2', # Zero Flag
	  'SREG_C': '$1', # Carry Flag
	'SP' : '$5d', # Stack Pointer 
	'MCUCR' : '$55', # MCU Control Register
	  'MCUCR_PUD': '$10', # Pull-up disable
	  'MCUCR_IVSEL': '$2', # Interrupt Vector Select
	  'MCUCR_IVCE': '$1', # Interrupt Vector Change Enable
	'MCUSR' : '$54', # MCU Status Register
	  'MCUSR_JTRF': '$10', # JTAG Reset Flag
	  'MCUSR_WDRF': '$8', # Watchdog Reset Flag
	  'MCUSR_BORF': '$4', # Brown-out Reset Flag
	  'MCUSR_EXTRF': '$2', # External Reset Flag
	  'MCUSR_PORF': '$1', # Power-on reset flag
	'XMCRA' : '$74', # External Memory Control Regist
	  'XMCRA_SRE': '$80', # External SRAM Enable
	  'XMCRA_SRL': '$70', # Wait state page limit
	  'XMCRA_SRW1': '$c', # Wait state select bit upper pa
	  'XMCRA_SRW0': '$3', # Wait state select bit lower pa
	'XMCRB' : '$75', # External Memory Control Regist
	  'XMCRB_XMBK': '$80', # External Memory Bus Keeper Ena
	  'XMCRB_XMM': '$7', # External Memory High Mask
	'OSCCAL' : '$66', # Oscillator Calibration Value
	'CLKPR' : '$61', # Clock Prescale Register
	  'CLKPR_CLKPCE': '$80', # 
	  'CLKPR_CLKPS': '$f', # 
	'SMCR' : '$53', # Sleep Mode Control Register
	  'SMCR_SM': '$e', # Sleep Mode Select bits
	  'SMCR_SE': '$1', # Sleep Enable
	'RAMPZ' : '$5b', # RAM Page Z Select Register - N
	  'RAMPZ_RAMPZ0': '$1', # RAM Page Z Select Register Bit
	'GPIOR2' : '$4b', # General Purpose IO Register 2
	  'GPIOR2_GPIOR': '$ff', # General Purpose IO Register 2 
	'GPIOR1' : '$4a', # General Purpose IO Register 1
	  'GPIOR1_GPIOR': '$ff', # General Purpose IO Register 1 
	'GPIOR0' : '$3e', # General Purpose IO Register 0
	  'GPIOR0_GPIOR07': '$80', # General Purpose IO Register 0 
	  'GPIOR0_GPIOR06': '$40', # General Purpose IO Register 0 
	  'GPIOR0_GPIOR05': '$20', # General Purpose IO Register 0 
	  'GPIOR0_GPIOR04': '$10', # General Purpose IO Register 0 
	  'GPIOR0_GPIOR03': '$8', # General Purpose IO Register 0 
	  'GPIOR0_GPIOR02': '$4', # General Purpose IO Register 0 
	  'GPIOR0_GPIOR01': '$2', # General Purpose IO Register 0 
	  'GPIOR0_GPIOR00': '$1', # General Purpose IO Register 0 

# Module BOOT_LOAD
	'SPMCSR' : '$57', # Store Program Memory Control R
	  'SPMCSR_SPMIE': '$80', # SPM Interrupt Enable
	  'SPMCSR_RWWSB': '$40', # Read While Write Section Busy
	  'SPMCSR_RWWSRE': '$10', # Read While Write section read 
	  'SPMCSR_BLBSET': '$8', # Boot Lock Bit Set
	  'SPMCSR_PGWRT': '$4', # Page Write
	  'SPMCSR_PGERS': '$2', # Page Erase
	  'SPMCSR_SPMEN': '$1', # Store Program Memory Enable

# Module EXTERNAL_INTERRUPT
	'EICRA' : '$69', # External Interrupt Control Reg
	  'EICRA_ISC3': '$c0', # External Interrupt Sense Contr
	  'EICRA_ISC2': '$30', # External Interrupt Sense Contr
	  'EICRA_ISC1': '$c', # External Interrupt Sense Contr
	  'EICRA_ISC0': '$3', # External Interrupt Sense Contr
	'EICRB' : '$6a', # External Interrupt Control Reg
	  'EICRB_ISC7': '$c0', # External Interrupt 7-4 Sense C
	  'EICRB_ISC6': '$30', # External Interrupt 7-4 Sense C
	  'EICRB_ISC5': '$c', # External Interrupt 7-4 Sense C
	  'EICRB_ISC4': '$3', # External Interrupt 7-4 Sense C
	'EIMSK' : '$3d', # External Interrupt Mask Regist
	  'EIMSK_INT': '$ff', # External Interrupt Request 7 E
	'EIFR' : '$3c', # External Interrupt Flag Regist
	  'EIFR_INTF': '$ff', # External Interrupt Flags

# Module EEPROM
	'EEAR' : '$41', # EEPROM Read/Write Access  Byte
	'EEDR' : '$40', # EEPROM Data Register
	'EECR' : '$3f', # EEPROM Control Register
	  'EECR_EERIE': '$8', # EEPROM Ready Interrupt Enable
	  'EECR_EEMWE': '$4', # EEPROM Master Write Enable
	  'EECR_EEWE': '$2', # EEPROM Write Enable
	  'EECR_EERE': '$1', # EEPROM Read Enable

# Module TIMER_COUNTER_0
	'TCCR0A' : '$44', # Timer/Counter0 Control Registe
	  'TCCR0A_FOC0A': '$80', # Force Output Compare
	  'TCCR0A_WGM00': '$40', # Waveform Generation Mode 0
	  'TCCR0A_COM0A': '$30', # Compare Match Output Modes
	  'TCCR0A_WGM01': '$8', # Waveform Generation Mode 1
	  'TCCR0A_CS0': '$7', # Clock Selects
	'TCNT0' : '$46', # Timer/Counter0
	'OCR0A' : '$47', # Timer/Counter0 Output Compare 
	'TIMSK0' : '$6e', # Timer/Counter0 Interrupt Mask 
	  'TIMSK0_OCIE0A': '$2', # Timer/Counter0 Output Compare 
	  'TIMSK0_TOIE0': '$1', # Timer/Counter0 Overflow Interr
	'TIFR0' : '$35', # Timer/Counter0 Interrupt Flag 
	  'TIFR0_OCF0A': '$2', # Timer/Counter0 Output Compare 
	  'TIFR0_TOV0': '$1', # Timer/Counter0 Overflow Flag
	'GTCCR' : '$43', # General Timer/Control Register
	  'GTCCR_TSM': '$80', # Timer/Counter Synchronization 
	  'GTCCR_PSR310': '$1', # Prescaler Reset Timer/Counter1

# Module TIMER_COUNTER_2
	'TCCR2' : '$b0', # Timer/Counter2 Control Registe
	  'TCCR2_FOC2A': '$80', # Force Output Compare
	  'TCCR2_WGM20': '$40', # Waveform Genration Mode
	  'TCCR2_COM2A': '$30', # Compare Output Mode bits
	  'TCCR2_WGM21': '$8', # Waveform Generation Mode
	  'TCCR2_CS2': '$7', # Clock Select bits
	'TCNT2' : '$b2', # Timer/Counter2
	'OCR2A' : '$b3', # Timer/Counter2 Output Compare 
	'TIMSK2' : '$70', # Timer/Counter Interrupt Mask r
	  'TIMSK2_OCIE2A': '$2', # Timer/Counter2 Output Compare 
	  'TIMSK2_TOIE2': '$1', # Timer/Counter2 Overflow Interr
	'TIFR2' : '$37', # Timer/Counter Interrupt Flag R
	  'TIFR2_OCF2A': '$2', # Output Compare Flag 2
	  'TIFR2_TOV2': '$1', # Timer/Counter2 Overflow Flag
	'GTCCR' : '$43', # General Timer/Counter Control 
	  'GTCCR_PSR2': '$2', # Prescaler Reset Timer/Counter2
	'ASSR' : '$b6', # Asynchronous Status Register
	  'ASSR_EXCLK': '$10', # Enable External Clock Interrup
	  'ASSR_AS2': '$8', # AS2: Asynchronous Timer/Counte
	  'ASSR_TCN2UB': '$4', # TCN2UB: Timer/Counter2 Update 
	  'ASSR_OCR2UB': '$2', # Output Compare Register2 Updat
	  'ASSR_TCR2UB': '$1', # TCR2UB: Timer/Counter Control 

# Module TIMER_COUNTER_1
	'TCCR1A' : '$80', # Timer/Counter1 Control Registe
	  'TCCR1A_COM1A': '$c0', # Compare Output Mode 1A, bits
	  'TCCR1A_COM1B': '$30', # Compare Output Mode 1B, bits
	  'TCCR1A_COM1C': '$c', # Compare Output Mode 1C, bits
	  'TCCR1A_WGM1': '$3', # Waveform Generation Mode
	'TCCR1B' : '$81', # Timer/Counter1 Control Registe
	  'TCCR1B_ICNC1': '$80', # Input Capture 1 Noise Canceler
	  'TCCR1B_ICES1': '$40', # Input Capture 1 Edge Select
	  'TCCR1B_WGM1': '$18', # Waveform Generation Mode
	  'TCCR1B_CS1': '$7', # Prescaler source of Timer/Coun
	'TCCR1C' : '$82', # Timer/Counter 1 Control Regist
	  'TCCR1C_FOC1A': '$80', # Force Output Compare 1A
	  'TCCR1C_FOC1B': '$40', # Force Output Compare 1B
	  'TCCR1C_FOC1C': '$20', # Force Output Compare 1C
	'TCNT1' : '$84', # Timer/Counter1  Bytes
	'OCR1A' : '$88', # Timer/Counter1 Output Compare 
	'OCR1B' : '$8a', # Timer/Counter1 Output Compare 
	'OCR1C' : '$8c', # Timer/Counter1 Output Compare 
	'ICR1' : '$86', # Timer/Counter1 Input Capture R
	'TIMSK1' : '$6f', # Timer/Counter Interrupt Mask R
	  'TIMSK1_ICIE1': '$20', # Timer/Counter1 Input Capture I
	  'TIMSK1_OCIE1C': '$8', # Timer/Counter1 Output CompareC
	  'TIMSK1_OCIE1B': '$4', # Timer/Counter1 Output CompareB
	  'TIMSK1_OCIE1A': '$2', # Timer/Counter1 Output CompareA
	  'TIMSK1_TOIE1': '$1', # Timer/Counter1 Overflow Interr
	'TIFR1' : '$36', # Timer/Counter Interrupt Flag r
	  'TIFR1_ICF1': '$20', # Input Capture Flag 1
	  'TIFR1_OCF1C': '$8', # Output Compare Flag 1C
	  'TIFR1_OCF1B': '$4', # Output Compare Flag 1B
	  'TIFR1_OCF1A': '$2', # Output Compare Flag 1A
	  'TIFR1_TOV1': '$1', # Timer/Counter1 Overflow Flag

# Module TIMER_COUNTER_3
	'TCCR3A' : '$90', # Timer/Counter3 Control Registe
	  'TCCR3A_COM3A': '$c0', # Compare Output Mode 3A, bits
	  'TCCR3A_COM3B': '$30', # Compare Output Mode 3B, bits
	  'TCCR3A_COM3C': '$c', # Compare Output Mode 3C, bits
	  'TCCR3A_WGM3': '$3', # Waveform Generation Mode
	'TCCR3B' : '$91', # Timer/Counter3 Control Registe
	  'TCCR3B_ICNC3': '$80', # Input Capture 3 Noise Canceler
	  'TCCR3B_ICES3': '$40', # Input Capture 3 Edge Select
	  'TCCR3B_WGM3': '$18', # Waveform Generation Mode
	  'TCCR3B_CS3': '$7', # Prescaler source of Timer/Coun
	'TCCR3C' : '$92', # Timer/Counter 3 Control Regist
	  'TCCR3C_FOC3A': '$80', # Force Output Compare 3A
	  'TCCR3C_FOC3B': '$40', # Force Output Compare 3B
	  'TCCR3C_FOC3C': '$20', # Force Output Compare 3C
	'TCNT3' : '$94', # Timer/Counter3  Bytes
	'OCR3A' : '$98', # Timer/Counter3 Output Compare 
	'OCR3B' : '$9a', # Timer/Counter3 Output Compare 
	'OCR3C' : '$9c', # Timer/Counter3 Output Compare 
	'ICR3' : '$96', # Timer/Counter3 Input Capture R
	'TIMSK3' : '$71', # Timer/Counter Interrupt Mask R
	  'TIMSK3_ICIE3': '$20', # Timer/Counter3 Input Capture I
	  'TIMSK3_OCIE3C': '$8', # Timer/Counter3 Output CompareC
	  'TIMSK3_OCIE3B': '$4', # Timer/Counter3 Output CompareB
	  'TIMSK3_OCIE3A': '$2', # Timer/Counter3 Output CompareA
	  'TIMSK3_TOIE3': '$1', # Timer/Counter3 Overflow Interr
	'TIFR3' : '$38', # Timer/Counter Interrupt Flag r
	  'TIFR3_ICF3': '$20', # Input Capture Flag 3
	  'TIFR3_OCF3C': '$8', # Output Compare Flag 3C
	  'TIFR3_OCF3B': '$4', # Output Compare Flag 3B
	  'TIFR3_OCF3A': '$2', # Output Compare Flag 3A
	  'TIFR3_TOV3': '$1', # Timer/Counter3 Overflow Flag

# Module WATCHDOG
	'WDTCR' : '$60', # Watchdog Timer Control Registe
	  'WDTCR_WDCE': '$10', # Watchdog Change Enable
	  'WDTCR_WDE': '$8', # Watch Dog Enable
	  'WDTCR_WDP': '$7', # Watch Dog Timer Prescaler bits

# Module AD_CONVERTER
	'ADMUX' : '$7c', # The ADC multiplexer Selection 
	  'ADMUX_REFS': '$c0', # Reference Selection Bits
	  'ADMUX_ADLAR': '$20', # Left Adjust Result
	  'ADMUX_MUX': '$1f', # Analog Channel and Gain Select
	'ADCSRA' : '$7a', # The ADC Control and Status reg
	  'ADCSRA_ADEN': '$80', # ADC Enable
	  'ADCSRA_ADSC': '$40', # ADC Start Conversion
	  'ADCSRA_ADATE': '$20', # ADC Auto Trigger Enable
	  'ADCSRA_ADIF': '$10', # ADC Interrupt Flag
	  'ADCSRA_ADIE': '$8', # ADC Interrupt Enable
	  'ADCSRA_ADPS': '$7', # ADC  Prescaler Select Bits
	'ADC' : '$78', # ADC Data Register  Bytes
	'ADCSRB' : '$7b', # ADC Control and Status Registe
	  'ADCSRB_ADHSM': '$80', # ADC High Speed Mode
	  'ADCSRB_ADTS': '$7', # ADC Auto Trigger Sources
	'DIDR0' : '$7e', # Digital Input Disable Register
	  'DIDR0_ADC7D': '$80', # ADC7 Digital input Disable
	  'DIDR0_ADC6D': '$40', # ADC6 Digital input Disable
	  'DIDR0_ADC5D': '$20', # ADC5 Digital input Disable
	  'DIDR0_ADC4D': '$10', # ADC4 Digital input Disable
	  'DIDR0_ADC3D': '$8', # ADC3 Digital input Disable
	  'DIDR0_ADC2D': '$4', # ADC2 Digital input Disable
	  'DIDR0_ADC1D': '$2', # ADC1 Digital input Disable
	  'DIDR0_ADC0D': '$1', # ADC0 Digital input Disable

# Module ANALOG_COMPARATOR
	'ADCSRB' : '$7b', # ADC Control and Status Registe
	  'ADCSRB_ACME': '$40', # Analog Comparator Multiplexer 
	'ACSR' : '$50', # Analog Comparator Control And 
	  'ACSR_ACD': '$80', # Analog Comparator Disable
	  'ACSR_ACBG': '$40', # Analog Comparator Bandgap Sele
	  'ACSR_ACO': '$20', # Analog Compare Output
	  'ACSR_ACI': '$10', # Analog Comparator Interrupt Fl
	  'ACSR_ACIE': '$8', # Analog Comparator Interrupt En
	  'ACSR_ACIC': '$4', # Analog Comparator Input Captur
	  'ACSR_ACIS': '$3', # Analog Comparator Interrupt Mo
	'DIDR1' : '$7f', # 
	  'DIDR1_AIN1D': '$2', # AIN1 Digital Input Disable
	  'DIDR1_AIN0D': '$1', # AIN0 Digital Input Disable

# Module CAN
	'CANGCON' : '$d8', # CAN General Control Register
	  'CANGCON_ABRQ': '$80', # Abort Request
	  'CANGCON_OVRQ': '$40', # Overload Frame Request
	  'CANGCON_TTC': '$20', # Time Trigger Communication
	  'CANGCON_SYNTTC': '$10', # Synchronization of TTC
	  'CANGCON_LISTEN': '$8', # Listening Mode
	  'CANGCON_TEST': '$4', # Test Mode
	  'CANGCON_ENASTB': '$2', # Enable / Standby
	  'CANGCON_SWRES': '$1', # Software Reset Request
	'CANGSTA' : '$d9', # CAN General Status Register
	  'CANGSTA_OVRG': '$40', # Overload Frame Flag
	  'CANGSTA_TXBSY': '$10', # Transmitter Busy
	  'CANGSTA_RXBSY': '$8', # Receiver Busy
	  'CANGSTA_ENFG': '$4', # Enable Flag
	  'CANGSTA_BOFF': '$2', # Bus Off Mode
	  'CANGSTA_ERRP': '$1', # Error Passive Mode
	'CANGIT' : '$da', # CAN General Interrupt Register
	  'CANGIT_CANIT': '$80', # General Interrupt Flag
	  'CANGIT_BOFFIT': '$40', # Bus Off Interrupt Flag
	  'CANGIT_OVRTIM': '$20', # Overrun CAN Timer
	  'CANGIT_BXOK': '$10', # Burst Receive Interrupt
	  'CANGIT_SERG': '$8', # Stuff Error General
	  'CANGIT_CERG': '$4', # CRC Error General
	  'CANGIT_FERG': '$2', # Form Error General
	  'CANGIT_AERG': '$1', # Ackknowledgement Error General
	'CANGIE' : '$db', # CAN General Interrupt Enable R
	  'CANGIE_ENIT': '$80', # Enable all Interrupts
	  'CANGIE_ENBOFF': '$40', # Enable Bus Off INterrupt
	  'CANGIE_ENRX': '$20', # Enable Receive Interrupt
	  'CANGIE_ENTX': '$10', # Enable Transmitt Interrupt
	  'CANGIE_ENERR': '$8', # Enable MOb Error Interrupt
	  'CANGIE_ENBX': '$4', # Enable Burst Receive Interrupt
	  'CANGIE_ENERG': '$2', # Enable General Error Interrupt
	  'CANGIE_ENOVRT': '$1', # Enable CAN Timer Overrun Inter
	'CANEN2' : '$dc', # Enable MOb Register
	'CANEN1' : '$dd', # Enable MOb Register
	'CANIE2' : '$de', # Enable Interrupt MOb Register
	'CANIE1' : '$df', # Enable Interrupt MOb Register
	'CANSIT2' : '$e0', # CAN Status Interrupt MOb Regis
	'CANSIT1' : '$e1', # CAN Status Interrupt MOb Regis
	'CANBT1' : '$e2', # Bit Timing Register 1
	  'CANBT1_BRP': '$7e', # Baud Rate Prescaler bits
	'CANBT2' : '$e3', # Bit Timing Register 2
	  'CANBT2_SJW': '$60', # Re-Sync Jump Width
	  'CANBT2_PRS': '$e', # Propagation Time Segment
	'CANBT3' : '$e4', # Bit Timing Register 3
	  'CANBT3_PHS2': '$70', # Phase Segments
	  'CANBT3_PHS1': '$e', # Phase Segment 1
	  'CANBT3_SMP': '$1', # Sample Type
	'CANTCON' : '$e5', # Timer Control Register
	'CANTIML' : '$e6', # Timer Register Low
	'CANTIMH' : '$e7', # Timer Register High
	'CANTTCL' : '$e8', # TTC Timer Register Low
	'CANTTCH' : '$e9', # TTC Timer Register High
	'CANTEC' : '$ea', # Transmit Error Counter Registe
	'CANREC' : '$eb', # Receive Error Counter Register
	'CANHPMOB' : '$ec', # Highest Priority MOb Register
	'CANPAGE' : '$ed', # Page MOb Register
	  'CANPAGE_MOBNB': '$f0', # MOb Number Bits
	  'CANPAGE_AINC': '$8', # MOb Data Buffer Auto Increment
	  'CANPAGE_INDX': '$7', # Data Buffer Index Bits
	'CANSTMOB' : '$ee', # MOb Status Register
	  'CANSTMOB_DLCW': '$80', # Data Length Code Warning
	  'CANSTMOB_TXOK': '$40', # Transmit OK
	  'CANSTMOB_RXOK': '$20', # Receive OK
	  'CANSTMOB_BERR': '$10', # Bit Error
	  'CANSTMOB_SERR': '$8', # Stuff Error
	  'CANSTMOB_CERR': '$4', # CRC Error
	  'CANSTMOB_FERR': '$2', # Form Error
	  'CANSTMOB_AERR': '$1', # Ackknowledgement Error
	'CANCDMOB' : '$ef', # MOb Control and DLC Register
	  'CANCDMOB_CONMOB': '$c0', # MOb Config Bits
	  'CANCDMOB_RPLV': '$20', # Reply Valid
	  'CANCDMOB_IDE': '$10', # Identifier Extension
	  'CANCDMOB_DLC': '$f', # Data Length Code Bits
	'CANIDT4' : '$f0', # Identifier Tag Register 4
	'CANIDT3' : '$f1', # Identifier Tag Register 3
	'CANIDT2' : '$f2', # Identifier Tag Register 2
	'CANIDT1' : '$f3', # Identifier Tag Register 1
	'CANIDM4' : '$f4', # Identifier Mask Register 4
	'CANIDM3' : '$f5', # Identifier Mask Register 3
	'CANIDM2' : '$f6', # Identifier Mask Register 2
	'CANIDM1' : '$f7', # Identifier Mask Register 1
	'CANSTML' : '$f8', # Time Stamp Register Low
	'CANSTMH' : '$f9', # Time Stamp Register High
	'CANMSG' : '$fa', # Message Data Register

	  '__amforth_dummy':'0'
}
